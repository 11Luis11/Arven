import { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MessageSquare, ArrowLeft, Shield, AlertTriangle, Star } from 'lucide-react';
import { DataService } from '../services/dataService';
import SEO from '../components/SEO';

export default function ProductDetail({ onOpenCart }) {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [config, setConfig] = useState(null);
  const [recommended, setRecommended] = useState([]);
  const [activeImage, setActiveImage] = useState('');
  const [selectedSize, setSelectedSize] = useState('M');
  const [selectedColor, setSelectedColor] = useState(null);
  const [loading, setLoading] = useState(true);

  // Zoom reference variables
  const imageContainerRef = useRef(null);
  const zoomImageRef = useRef(null);

  useEffect(() => {
    const fetchProduct = async () => {
      setLoading(true);
      const prods = await DataService.getProducts();
      const found = prods.find(p => p.id === id);
      
      if (found) {
        setProduct(found);
        const imgList = found.images && found.images.length > 0 ? found.images : [found.image_url];
        setActiveImage(imgList[0]);

        if (found.colors && found.colors.length > 0) {
          setSelectedColor(found.colors[0]);
          if (found.colors[0].image_url) {
            setActiveImage(found.colors[0].image_url);
          }
        } else {
          setSelectedColor(null);
        }

        if (found.sizes && found.sizes.length > 0) {
          setSelectedSize(found.sizes[0]);
        } else {
          setSelectedSize('M');
        }

        // Filtrar recomendados de la misma categoría, excluyendo el actual
        const similar = prods
          .filter(p => p.category_id === found.category_id && p.id !== found.id && p.active)
          .slice(0, 3);
        setRecommended(similar);
      }
      const cfg = await DataService.getConfig();
      setConfig(cfg);
      setLoading(false);
    };
    fetchProduct();
  }, [id]);

  const getSelectedCombinationStock = () => {
    if (!product) return 0;
    if (selectedColor) {
      if (product.sizes && product.sizes.length > 0) {
        if (selectedColor.sizes_stock) {
          return selectedColor.sizes_stock[selectedSize] || 0;
        }
        return 0;
      }
      return selectedColor.stock || 0;
    }
    return product.stock || 0;
  };

  const buyViaWhatsApp = () => {
    if (!product) return;
    const phone = config?.footer?.whatsapp || '';
    const cleanPhone = phone.replace(/\D/g, ''); // limpia números, quitando espacios, + y guiones
    
    // Obtener precio correspondiente (oferta o regular)
    const activePrice = product.offer_price || product.price;
    
    const message = `Hola, me gustaría comprar este polo:
🛍️ *Polo:* ${product.name}
🎨 *Color:* ${selectedColor ? selectedColor.name : 'No especificado'}
📏 *Talla:* ${selectedSize}
💰 *Precio:* S/. ${activePrice.toFixed(2)}

¿Tienen stock disponible para coordinar la entrega?`;

    const encodedText = encodeURIComponent(message);
    const url = `https://wa.me/${cleanPhone || '51987654321'}?text=${encodedText}`;
    window.open(url, '_blank');
  };

  // Lupa / Hover Zoom
  const handleMouseMove = (e) => {
    if (!zoomImageRef.current || !imageContainerRef.current) return;
    
    const container = imageContainerRef.current;
    const img = zoomImageRef.current;
    
    const { left, top, width, height } = container.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;

    window.requestAnimationFrame(() => {
      img.style.transformOrigin = `${x}% ${y}%`;
      img.style.transform = 'scale(1.8)';
    });
  };

  const handleMouseLeave = () => {
    if (zoomImageRef.current) {
      window.requestAnimationFrame(() => {
        zoomImageRef.current.style.transform = 'scale(1)';
        zoomImageRef.current.style.transformOrigin = 'center center';
      });
    }
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '100px 24px', minHeight: '60vh' }}>
        <p style={{ color: 'var(--text-secondary)' }}>Cargando polo premium...</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div style={{ textAlign: 'center', padding: '100px 24px', minHeight: '60vh' }}>
        <h2 style={{ marginBottom: '16px' }}>Producto no encontrado</h2>
        <Link to="/catalog" className="btn-primary" style={{ borderRadius: '0px' }}>
          Volver al catálogo
        </Link>
      </div>
    );
  }

  const sizePrices = (product.wholesale_tiers || []).find(t => t.type === 'size_prices')?.data || {};
  const sizeData = sizePrices[selectedSize];
  
  const price = (sizeData?.offer_price && sizeData.offer_price !== '')
    ? parseFloat(sizeData.offer_price)
    : ((sizeData?.price && sizeData.price !== '')
      ? parseFloat(sizeData.price)
      : (product.offer_price || product.price));

  const originalPrice = (sizeData?.offer_price && sizeData.offer_price !== '' && sizeData?.price && sizeData.price !== '')
    ? parseFloat(sizeData.price)
    : ((product.offer_price && (!sizeData?.price || sizeData.price === '')) ? product.price : null);

  const imageList = product.images && product.images.length > 0 ? product.images : [product.image_url];

  return (
    <div style={{ padding: '40px 24px', maxWidth: '1200px', marginLeft: 'auto', marginRight: 'auto', width: '100%', minHeight: '80vh' }}>
      <SEO title={product.name} description={product.description} ogImage={activeImage} />

      <Link 
        to="/catalog" 
        style={{ 
          display: 'inline-flex', 
          alignItems: 'center', 
          gap: '8px', 
          fontSize: '13px', 
          color: 'var(--text-secondary)',
          marginBottom: '32px'
        }}
      >
        <ArrowLeft size={16} /> Volver al catálogo
      </Link>

      {/* Grid Principal Detalle */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1.2fr 1fr',
        gap: '48px',
        alignItems: 'start',
        marginBottom: '80px'
      }}>
        
        {/* COLUMNA IZQUIERDA: GALERÍA + DESCRIPCIÓN */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '32px', position: 'sticky', top: '90px', alignSelf: 'start' }}>
          
          {/* GALERÍA DE IMÁGENES + ZOOM HOVER */}
          <div style={{ display: 'flex', gap: '16px' }}>
            {/* Miniaturas */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {imageList.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImage(img)}
                  style={{
                    width: '60px',
                    height: '80px',
                    border: activeImage === img ? '1.5px solid var(--text-primary)' : '1px solid var(--border-color)',
                    backgroundColor: '#FFF',
                    padding: '2px',
                    cursor: 'pointer',
                    overflow: 'hidden'
                  }}
                >
                  <img src={img} alt="Miniatura" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </button>
              ))}
            </div>

            {/* Imagen Principal con Zoom */}
            <div 
              ref={imageContainerRef}
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
              style={{
                flex: 1,
                border: '1px solid var(--border-color)',
                backgroundColor: '#FFF',
                overflow: 'hidden',
                cursor: 'zoom-in',
                position: 'relative',
                height: '520px'
              }}
            >
              <img 
                ref={zoomImageRef}
                src={activeImage} 
                alt={product.name}
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                  display: 'block',
                  transition: 'transform 0.1s ease-out',
                  willChange: 'transform'
                }}
              />
            </div>
          </div>

          {/* Descripción debajo de la imagen */}
          <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '20px' }}>
            <h3 style={{ fontSize: '14px', fontWeight: 550, marginBottom: '10px', textTransform: 'uppercase', letterSpacing: '0.04em', color: 'var(--text-primary)' }}>Descripción</h3>
            <p style={{ fontSize: '14px', color: 'var(--text-secondary)', lineHeight: 1.6, fontWeight: 300, whiteSpace: 'pre-wrap' }}>
              {product.description}
            </p>
          </div>
        </div>

        {/* Ficha e Información */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <div>
            <span style={{ fontSize: '11px', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--text-secondary)' }}>
              Colección Carrillo
            </span>
            <h1 style={{ fontSize: '28px', fontWeight: 500, marginTop: '8px', marginBottom: '12px' }}>{product.name}</h1>
            <p style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>SKU: {product.sku}</p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span style={{ fontSize: '24px', fontWeight: 600 }}>
              S/. {price.toFixed(2)}
            </span>
            {originalPrice && (
              <span style={{ fontSize: '16px', textDecoration: 'line-through', color: 'var(--text-secondary)' }}>
                S/. {originalPrice.toFixed(2)}
              </span>
            )}
          </div>
          
          {(() => {
            const selectedSizeData = sizePrices[selectedSize];
            const tiers = selectedSizeData?.wholesale_tiers || [];
            if (tiers.length === 0) return null;

            return (
              <div style={{ marginTop: '4px' }}>
                <div style={{
                  display: 'flex',
                  gap: '0px',
                  flexWrap: 'wrap',
                  border: '1px solid #E0E7FF',
                  borderRadius: '4px',
                  overflow: 'hidden'
                }}>
                  {tiers.map((tier, idx) => {
                    const nextTier = tiers[idx + 1];
                    const rangeLabel = nextTier
                      ? `${tier.min_qty}-${nextTier.min_qty - 1} Piezas`
                      : `${tier.min_qty}+ Piezas`;

                    return (
                      <div
                        key={idx}
                        style={{
                          flex: '1 1 0',
                          minWidth: '100px',
                          padding: '14px 12px',
                          textAlign: 'center',
                          backgroundColor: idx === 0 ? '#EEF2FF' : idx === 1 ? '#E8EDFF' : '#E0E5FF',
                          borderRight: idx < tiers.length - 1 ? '1px solid #D0D5FF' : 'none',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '4px'
                        }}
                      >
                        <span style={{
                          fontSize: '18px',
                          fontWeight: 700,
                          color: '#1E1B4B',
                          letterSpacing: '-0.02em'
                        }}>
                          S/. {parseFloat(tier.price).toFixed(2)}
                        </span>
                        <span style={{
                          fontSize: '11px',
                          color: '#6366F1',
                          fontWeight: 500,
                          letterSpacing: '0.02em'
                        }}>
                          {rangeLabel}
                        </span>
                      </div>
                    );
                  })}
                </div>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  marginTop: '8px',
                  fontSize: '11px',
                  color: '#6366F1',
                  fontWeight: 600,
                  letterSpacing: '0.04em'
                }}>
                  <span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: '16px', height: '16px', backgroundColor: '#6366F1', color: '#FFF', borderRadius: '50%', fontSize: '10px', fontWeight: 700 }}>%</span>
                  PRECIOS AL POR MAYOR DISPONIBLES EN TALLA {selectedSize}
                </div>
              </div>
            );
          })()}

          {(() => {
            const simplePromos = (product.wholesale_tiers || []).find(t => t.type === 'simple_promos')?.data || [];
            if (simplePromos.length === 0) return null;

            return (
              <div style={{
                marginTop: '12px',
                padding: '14px 16px',
                backgroundColor: '#FFF0F3',
                border: '1px solid #FFCCD5',
                color: '#C9184A',
                fontWeight: 600,
                fontSize: '13px',
                display: 'flex',
                flexDirection: 'column',
                gap: '6px'
              }}>
                <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.05em', color: '#FF4D6D', fontWeight: 700 }}>🔥 Promoción Especial</span>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  {simplePromos.map((promo, idx) => (
                    <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span>Lleva {promo.qty} polos por solo:</span>
                      <strong>S/. {parseFloat(promo.price).toFixed(2)}</strong>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}

          {/* Colores */}
          {product.colors && product.colors.length > 0 && (
            <div>
              <h3 style={{ fontSize: '14px', fontWeight: 500, marginBottom: '12px' }}>Seleccionar Color: <span style={{ fontWeight: 'normal', color: 'var(--text-secondary)' }}>{selectedColor ? selectedColor.name : ''}</span></h3>
              <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                {product.colors.map((c) => {
                  const isSelected = selectedColor?.hex?.toLowerCase() === c.hex?.toLowerCase();
                  return (
                    <button
                      key={c.hex}
                      onClick={() => {
                        setSelectedColor(c);
                        if (c.image_url) setActiveImage(c.image_url);
                      }}
                      title={c.name}
                      style={{
                        width: '36px',
                        height: '36px',
                        borderRadius: '50%',
                        backgroundColor: c.hex,
                        border: isSelected ? '2px solid var(--text-primary)' : '1px solid var(--border-color)',
                        boxShadow: isSelected ? '0 0 0 2px #FFF, 0 0 0 4px var(--text-primary)' : 'none',
                        cursor: 'pointer',
                        transition: 'all 0.15s ease'
                      }}
                    />
                  );
                })}
              </div>
            </div>
          )}

          {/* Tallas */}
          {product.sizes && product.sizes.length > 0 && (
            <div>
              <h3 style={{ fontSize: '14px', fontWeight: 500, marginBottom: '12px' }}>Seleccionar Talla</h3>
              <div style={{ display: 'flex', gap: '10px' }}>
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    style={{
                      width: '44px',
                      height: '44px',
                      border: '1px solid var(--border-color)',
                      background: selectedSize === size ? 'var(--text-primary)' : '#FFF',
                      color: selectedSize === size ? '#FFF' : 'var(--text-primary)',
                      cursor: 'pointer',
                      fontSize: '13px',
                      fontWeight: 500,
                      transition: 'var(--transition-fast)'
                    }}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          )}

          {(() => {
            const combStock = getSelectedCombinationStock();
            if (combStock <= 5 && combStock > 0) {
              return (
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  backgroundColor: '#FFFBEB',
                  border: '1px solid #FEF3C7',
                  padding: '12px 16px',
                  fontSize: '13px',
                  color: '#B45309',
                  marginTop: '8px'
                }}>
                  <AlertTriangle size={16} />
                  <span>¡Solo quedan {combStock} unidades de esta combinación color/talla!</span>
                </div>
              );
            } else if (combStock === 0) {
              return (
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  backgroundColor: '#FFF5F5',
                  border: '1px solid #FED7D7',
                  padding: '12px 16px',
                  fontSize: '13px',
                  color: '#C53030',
                  marginTop: '8px'
                }}>
                  <AlertTriangle size={16} />
                  <span>Esta combinación color/talla no tiene stock disponible en este momento.</span>
                </div>
              );
            } else {
              return (
                <div style={{ fontSize: '13px', color: 'var(--text-secondary)', marginTop: '4px' }}>
                  Stock disponible: <strong>{combStock}</strong> unidades.
                </div>
              );
            }
          })()}

          <div style={{ marginTop: '12px' }}>
            <button
              onClick={buyViaWhatsApp}
              disabled={getSelectedCombinationStock() === 0}
              className="btn-primary"
              style={{
                width: '100%',
                padding: '16px',
                fontSize: '15px',
                borderRadius: '0px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '10px',
                backgroundColor: getSelectedCombinationStock() === 0 ? '#CBD5E1' : '#25D366',
                border: 'none',
                color: '#FFF',
                fontWeight: 700,
                cursor: getSelectedCombinationStock() === 0 ? 'not-allowed' : 'pointer'
              }}
            >
              <MessageSquare size={18} />
              {getSelectedCombinationStock() === 0 ? 'AGOTADO' : 'PEDIR POR WHATSAPP'}
            </button>
          </div>

          <div style={{
            padding: '16px',
            border: '1px solid var(--border-color)',
            display: 'flex',
            flexDirection: 'column',
            gap: '12px',
            fontSize: '13px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Shield size={16} style={{ color: 'var(--color-primary)' }} />
              <span>Garantía de cambios rápidos.</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Shield size={16} style={{ color: 'var(--color-primary)' }} />
              <span>Algodón premium de gramaje pesado.</span>
            </div>
          </div>
        </div>
      </div>

      {/* SECCIÓN RECOMENDADOS */}
      {recommended.length > 0 && (
        <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '60px' }}>
          <h2 style={{ fontSize: '22px', fontWeight: 500, marginBottom: '32px', textAlign: 'center' }}>
            También te podría gustar
          </h2>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '24px'
          }}>
            {recommended.map(prod => (
              <div key={prod.id} className="hover-subtle" style={{ border: '1px solid var(--border-color)', backgroundColor: '#FFF', display: 'flex', flexDirection: 'column' }}>
                <Link to={`/product/${prod.id}`} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '360px', overflow: 'hidden', backgroundColor: '#F8F8F8' }}>
                  <img src={prod.image_url} alt={prod.name} style={{ width: '100%', height: '100%', objectFit: 'contain', padding: '8px', transition: 'transform 0.6s ease' }} onMouseOver={e => e.currentTarget.style.transform = 'scale(1.05)'} onMouseOut={e => e.currentTarget.style.transform = 'scale(1)'} />
                </Link>
                <div style={{ padding: '16px', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                  <div>
                    <h3 style={{ fontSize: '14px', fontWeight: 500, marginBottom: '6px' }}>{prod.name}</h3>
                    <span style={{ fontSize: '14px', fontWeight: 600 }}>S/. {(prod.offer_price || prod.price).toFixed(2)}</span>
                  </div>
                  <Link 
                    to={`/product/${prod.id}`}
                    className="btn-primary"
                    style={{ width: '100%', fontSize: '12px', padding: '10px', marginTop: '12px', borderRadius: '0px', textAlign: 'center', display: 'block', textDecoration: 'none', color: '#FFF' }}
                  >
                    Ver Detalle
                  </Link>
                </div>
              </div>
            ))}  
          </div>
        </div>
      )}

    </div>
  );
}
